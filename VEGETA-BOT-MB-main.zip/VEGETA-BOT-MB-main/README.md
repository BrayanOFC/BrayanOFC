<h1 align="center">💨 𝑽𝑬𝑮𝑬𝑻𝑨-𝑩𝑶𝑻-𝑴𝑩 💨</h1>
<p align="center">🐉 ¡El Orgullo Saiyajin convertido en Bot de WhatsApp!</p>

![line](https://github.com/BrayanOFC/Lines-Neon-MB/raw/main/assets/Logo-neon.jpg)

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=0033FF&center=true&vCenter=true&width=600&lines=Bienvenido+Guerrero+Z;VEGETA-BOT-MB+🔥;Creado+desde+0+por+BrayanOFC;El+Orgullo+Saiyajin+en+tu+mano;¡Supera+a+Kakaroto!)](https://git.io/typing-svg)

![VEGETA](https://qu.ax/ijJBG.png)

> ⚡ Versión: **2.13.2**  
> 👑 Creador: **BrayanOFC – El Príncipe Saiyajin**

![line](https://github.com/BrayanOFC/Lines-Neon-MB/raw/main/assets/Logo-arcoiris.jpg)

<div align="center">

[![Dueño](https://img.shields.io/badge/Príncipe-0033FF?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/526633900512)
[![Soporte](https://img.shields.io/badge/Escuadrón_Z-0033FF?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/526633900512)
[![YouTube](https://img.shields.io/badge/Entrenamiento-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@Vegeta-bot)

</div>

![line](https://github.com/BrayanOFC/Lines-Neon-MB/raw/main/assets/Logo-azul.jpg)

### ❕️ **Información Saiyajin**

<details>
 <summary><b> 🐉 Origen del Poder</b></summary>

* Este bot **no está afiliado a WhatsApp Inc.**  
* WhatsApp es marca registrada de `WhatsApp LLC`.  
* **VEGETA-BOT-MB** fue forjado desde 0 como un arma de los Saiyajin para dominar WhatsApp ⚡  

> 🗣️ Vegeta: *"¡Este bot no necesita a Kakaroto para ser el mejor!"*  

</details>

![line](https://github.com/BrayanOFC/Lines-Neon-MB/raw/main/assets/Logo-neon.jpg)

### 🔮 **Contacto con el Reino Saiyajin**

<a href="https://wa.me/526641784469?text=Quiero+el+poder+de+VEGETA"><img src="https://qu.ax/ugHh.jpg" height="100px"></a>

<details>
<summary><b> 🐉 Comunicación Saiyajin</b></summary>

* WhatsApp: https://wa.me/526641784469  

> 🗣️ Vegeta: *"Si buscas poder… habla directamente con el príncipe de los Saiyajin."*  

</details>

![line](https://github.com/BrayanOFC/Lines-Neon-MB/raw/main/assets/logo-neon.gif)

### 🐉 **Descarga el Templo Saiyajin (Termux)** ☁️
<a href="https://www.mediafire.com/file/llugt4zgj7g3n3u/com.termux_1020.apk/file"><img src="https://qu.ax/finc.jpg" height="125px"></a> 

![line](https://github.com/BrayanOFC/Lines-Neon-MB/raw/main/assets/Logo-verde.jpg)
</details>

[![Termux](https://img.shields.io/badge/Instalacion-En%20Termux-000000?style=for-the-badge&logo=android&logoColor=white)](https://f-droid.org/es/packages/com.termux/)

<details>
 <summary><b> 🪄 Click aca Saiyajin🐉</b></summary>

#### Pasos del Guerrero Z
```bash
termux-setup-storage
```

```bash
apt update && apt upgrade && pkg install -y git nodejs ffmpeg imagemagick yarn
```

```bash
git clone https://github.com/BrayanOFC/VEGETA-BOT-MB && cd VEGETA-BOT-MB 
```

```bash
yarn install
```

```bash
npm install
```

![line](https://github.com/BrayanOFC/Lines-Neon-MB/raw/main/assets/Logo-arcoiris.jpg)

✨️ Revivir el Ki de Vegeta si se detiene

```bash
cd VEGETA-BOT-MB
npm start
```

✨️ Convertirte en el Owner Saiyajin

```bash
cd VEGETA-BOT-MB && nano config.js
```

> 🗣️ Vegeta: "No cualquiera puede portar este poder… pero si logras configurarlo, serás un verdadero Saiyajin."

![line](https://github.com/BrayanOFC/Lines-Neon-MB/raw/main/assets/Logo-rojo.jpg)
🎆 Modo Saiyajin 24/7 en Termux

```bash
npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs
```

> 🗣️ Vegeta: "Un Saiyajin nunca descansa, y tu bot tampoco debería hacerlo."
</details>


![line](https://github.com/BrayanOFC/Lines-Neon-MB/raw/main/assets/logo-neon.gif)

#### ☁️ Instalar desde Cloud Shell

<details>
 <summary><b> ⚡️ Ver comandos para Cloud Shell 🐉</b></summary>

```bash
apt update && apt upgrade
```

```bash
git clone https://github.com/BrayanOFC/VEGETA-BOT-MB && cd VEGETA-BOT-MB 
```

```bash
yarn install && npm install
```

```bash
npm start
```

✅ ¡Bot listo para usarse! El mejor bot de WhatsApp 🐉
</details>

![line](https://github.com/BrayanOFC/Lines-Neon-MB/raw/main/assets/logo-neon.gif)

🚀 Propietario Saiyajin

<a href="https://github.com/BrayanOFC"><img src="https://github.com/BrayanOFC.png" width="130" height="130" alt="BrayanOFC"/></a>

© Powered By Team BrayanOFC ⚡︎ – Orgullo Saiyajin


![line](https://github.com/BrayanOFC/Lines-Neon-MB/raw/main/assets/logo-neon.gif)

</details>

> 🐉 “El poder de un Saiyajin no tiene límites… y VEGETA-BOT-MB fue creado desde 0 para demostrarlo.”
🗣️ Vegeta: "¡Este bot superará a Kakaroto, lo juro por el orgullo Saiyajin!"